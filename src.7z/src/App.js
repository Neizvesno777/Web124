// import Header from './layot/Header';
// import Footer from './layot/Footer';
// import Main from './layot/Main';
import Dz from './Dz';

function App() {
  return (
    <div>
      {/* <Header />
      <Main />
      <Footer /> */}
      <Dz />
    </div>
  );
}

export default App;
