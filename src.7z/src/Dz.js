import './Dz.css'

function Dz () {  

    return (
        <div className="dz">
           <img src="https://via.placeholder.com/200x1000.png/FF0000?text=Red" alt="" />
           <img src="https://via.placeholder.com/200x1000.png/FF7F00?text=Orange" alt="" />
           <img src="https://via.placeholder.com/200x1000.png/FFFF00?text=Yellow" alt="" />
           <img src="https://via.placeholder.com/200x1000.png/00FF00?text=Green" alt="" />
           <img src="https://via.placeholder.com/200x1000.png/0000FF?text=Blue" alt="" />
           <img src="https://via.placeholder.com/200x1000.png/4B0082?text=Indigo" alt="" />
           <img src="https://via.placeholder.com/200x1000.png/9400D3?text=Purpule" alt="" />           
        </div>
    )
}

export default Dz;