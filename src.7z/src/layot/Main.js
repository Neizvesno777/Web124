import React from 'react';
import './Main.css';
import MoviList from '../components/MovieList';

class Main extends React.Component {

    state = {
        movies: []
    }

    componentDidMount() {
        fetch("http://www.omdbapi.com/?apikey=ee36665c&s=matrix")
            .then(response => response.json())
            .then(data => this.setState({ movies: data.Search }))
    }

    render() {
        const { movies } = this.state;
        return (
            <div className="main">
                <div className="wrap">
                    {
                        movies.length ? <MoviList movies={movies} /> : <h3>Loading...</h3>
                    }

                </div>
            </div>
        )
    }
}


export default Main;